package com.alura.foroinicial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoInicialApplicationTests {

	@Test
	void contextLoads() {
	}

}
