package com.alura.foro.persistence.DTO;

public record DatosJWTToken(String jwttoken) {

}
