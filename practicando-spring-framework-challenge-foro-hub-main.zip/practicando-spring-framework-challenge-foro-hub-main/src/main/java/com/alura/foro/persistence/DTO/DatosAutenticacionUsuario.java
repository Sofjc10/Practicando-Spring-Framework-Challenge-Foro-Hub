package com.alura.foro.persistence.DTO;

public record DatosAutenticacionUsuario(String nombreusuario, String contrasena) {

}
