package com.alura.foro.persistence.DTO;

public record ResponsePerfil(
		String nombrecompleto, 
		String email, 
		String nombreusuario) {

}
