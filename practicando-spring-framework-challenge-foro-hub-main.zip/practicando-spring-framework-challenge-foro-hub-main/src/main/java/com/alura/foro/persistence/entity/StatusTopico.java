package com.alura.foro.persistence.entity;

public enum StatusTopico {
	
	NO_RESPONDIDO,
	NO_SOLUCIONADO,
	SOLUCIONADO,
	CERRADO;

}
