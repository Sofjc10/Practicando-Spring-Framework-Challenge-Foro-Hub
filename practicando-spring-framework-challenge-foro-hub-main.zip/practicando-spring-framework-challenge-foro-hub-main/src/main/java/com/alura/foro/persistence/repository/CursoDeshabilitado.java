package com.alura.foro.persistence.repository;

public enum CursoDeshabilitado {
	TRUE,
	FALSE

}
